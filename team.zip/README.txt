Our application allows users to search for other users dependent on the search criteria. A base set of users is added via a JSON file when the program first runs. There is an option for a new user to sign up either as a faculty or as a student. Once logged in (or signed up) the user can search for other users based on the criteria entered on the screen. Then the user will be shown all the users with the search criteria provided. The user has the option to edit their profile and to save their profile to the database (JSON file). If the user does not save their profile before logging out, any changes are lost. 

Team Members for A-Team 63:
Ajman Naqib: naqib@wisc.edu
Ben Procknow: bprocknow@wisc.edu
Callan Patel: ccpatel2@wisc.edu
Erica Heying: eheying@wisc.edu
